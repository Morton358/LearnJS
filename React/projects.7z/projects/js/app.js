var my_news = [
{
	author: 'George Bucker',
	text: 'In Sunday morning on the main street of New York were terrible horror'
},
{
	author: 'Ann Fisher',
	text: 'At the train which goes from Douthland to Scotland people recognise in student of Harvard the copy of Harry Potter'
},
{
	author: 'Who',
	text: 'something'
}
];

var Article = React.createClass({
	render: function() {
		var author = this.props.dataset.author;
		var text = this.props.dataset.text;
		return (
			<div className="article">
				<p className="news__author">{author}:</p>
				<p className="news__text">{text}</p>
			</div>

			)
	}
	});


var News = React.createClass({
	 propTypes: {
    data: React.PropTypes.array.isRequired
  },
	render: function() {
		var data = this.props.data;
		var newsTemplate;
		if (data.length > 1) {
			newsTemplate = data.map(function(item, index) {
			return (

				<div key={index}>
					<Article dataset={item} />
				</div>
					)
				})
		
		} 
		else {
			newsTemplate = <p> Its a pity but we dont have any news today! </p>
		}
	return (
			<div className="news">
				{newsTemplate}
			<strong className={data.length > 0 ? 'news__count' : 'none'}> Count of news: {data.length} </strong>
			</div>	
		);
	}
});

var App = React.createClass({
  render: function() {
    return (
      <div className="app">
        <h3>News</h3>
        <News data={my_news}/> {/*adding property data*/}
      </div>
    );
  }
});

ReactDOM.render(
  <App />,
  document.getElementById('root')
);
